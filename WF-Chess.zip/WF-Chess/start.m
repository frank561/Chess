function a=start()

    field = repmat({' '}, 8);
    field(1,1)=({'R'});
    field(1,8)=({'R'});
    
    field(1,2)=({'N'});
    field(1,7)=({'N'});
    field(1,3)=({'B'});
    field(1,6)=({'B'});
    field(1,4)=({'Q'});
    field(1,5)=({'K'});
    for n=1:8
        field(2,n)=({'P'});
    end

    field(8,1)=({'r'});
    field(8,8)=({'r'});
    field(8,2)=({'n'});
    field(8,7)=({'n'});
    field(8,3)=({'b'});
    field(8,6)=({'b'});
    field(8,4)=({'q'});
    field(8,5)=({'k'});
    for n=1:8
        field(7,n)=({'p'});
    end
a=field