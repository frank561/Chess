function posPos=Rook(in)
    global handle;
    field=handle.field;
    i=1;
    posPos=[];
    while in(1)+i<9
            if field{in(1)+i,in(2)}==' '
                posPos=[posPos;[in(1)+i,in(2)]];
            else
                break
            end
        i = i + 1;    
    end
    i=1;
    while in(2)+i<9
            if field{in(1),in(2)+i}==' '
                posPos=[posPos;[in(1),in(2)+i]];
            else
                break
            end
        i = i + 1;    
    end
    i=1;
    while in(1)-i>0
            if field{in(1)-i,in(2)}==' '
               posPos=[posPos;[in(1)-i,in(2)]];
            else
                break
            end
        i = i + 1; 
    end
    i=1;
    while in(2)-i>0
            if field{in(1),in(2)-i}==' '
                posPos=[posPos;[in(1),in(2)-i]];
            else
                break
            end
        i = i + 1;
    end
end