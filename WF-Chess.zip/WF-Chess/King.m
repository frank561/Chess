function posPos=King(in)
    global handle;
    field=handle.field;
    posPos=[];
    if in(1)+1<9 && field{in(1)+1,in(2)}==' '
    	posPos=[posPos;[in(1)+1,in(2)]];
    end 
    if in(2)+1<9 && field{in(1),in(2)+1}==' '
    	posPos=[posPos;[in(1),in(2)+1]];
    end 
    if in(1)-1>0 && field{in(1)-1,in(2)}==' '
    	posPos=[posPos;[in(1)-1,in(2)]];
    end 
    if in(2)-1>0 && field{in(1),in(2)-1}==' '
    	posPos=[posPos;[in(1),in(2)-1]];
    end 
    if in(1)+1<9 && in(2)+1<9 && field{in(1)+1,in(2)+1}==' '
        posPos=[posPos;[in(1)+1,in(2)+1]];
    end
    if in(1)+1<9 && in(2)-1>0 && field{in(1)+1,in(2)-1}==' '
        posPos=[posPos;[in(1)+1,in(2)-1]];
    end
    if in(1)-1>0 && in(2)+1<9 && field{in(1)-1,in(2)+1}==' '
        posPos=[posPos;[in(1)-1,in(2)+1]];
    end
    if in(1)-1>0 && in(2)-1>0 && field{in(1)-1,in(2)-1}==' '
        posPos=[posPos;[in(1)-1,in(2)-1]];
    end
 end