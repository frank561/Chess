function posPos=Knight(in)
    global handle;
    field=handle.field;
    posPos=[];
    % + +
    if in(1)+2<9 && in(2)+1<9 && field{in(1)+2,in(2)+1}==' '
    	posPos=[posPos;[in(1)+2,in(2)+1]];
    end
    if in(1)+1<9 && in(2)+2<9 && field{in(1)+1,in(2)+2}==' '
    	posPos=[posPos;[in(1)+1,in(2)+2]];
    end
    % + -
    if in(1)+2<9 && in(2)-1>0 && field{in(1)+2,in(2)-1}==' '
    	posPos=[posPos;[in(1)+2,in(2)-1]];
    end
    if in(1)+1<9 && in(2)-2>0 && field{in(1)+1,in(2)-2}==' '
    	posPos=[posPos;[in(1)+1,in(2)-2]];
    end
    % - +
    if in(1)-2>0 && in(2)+1<9 && field{in(1)-2,in(2)+1}==' '
    	posPos=[posPos;[in(1)-2,in(2)+1]];
    end
    if in(1)-1>0 && in(2)+2<9 && field{in(1)-1,in(2)+2}==' '
    	posPos=[posPos;[in(1)-1,in(2)+2]];
    end
    % - -
    if in(1)-2>0 && in(2)-1>0 && field{in(1)-2,in(2)-1}==' '
    	posPos=[posPos;[in(1)-2,in(2)-1]];
    end
    if in(1)-1>0 && in(2)-2>0 && field{in(1)-1,in(2)-2}==' '
    	posPos=[posPos;[in(1)-1,in(2)-2]];
    end
 end