function posPos=movement(field,in)
    posPos=[];
    col=in(1);
    row=in(2);
    in=[row,col];
    switch lower(char(field(row,col)))    
        case char('p')
            disp('Pawn movement')
            posPos=Pawn(in);
        case char('n')
            disp('Knight movement')
            posPos=Knight(in);
        case char('r')
            disp('Rook movement')
            posPos=Rook(in);
        case char('b')
            disp('Bishop movement')
            posPos=Bishop(in);
        case char('q')
            disp('Queen movement')
            posPos=Queen(in);
        case char('k')
            disp('King movement')
            posPos=King(in);
        otherwise
            disp('Error-Please check your script')
    end
end