function RunChess()
    global handle;
    start()
    handle.gui = figure('name','Chess');
    handle.white = 1;
    refresh()
    
end