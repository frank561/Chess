function posPos=Pawn(in)
    global handle;
    field = handle.field;
    posPos=[];
    if handle.white
        if field{in(1)+1,in(2)}==' '
            posPos=[posPos;[in(1)+1,in(2)]];
        end
        if  in(2)<8 && double(field{in(1)+1,in(2)+1})>95
            posPos=[posPos;[in(1)+1,in(2)+1]];
        end
        if in(2)>1 && double(field{in(1)+1,in(2)-1})>95 
            posPos=[posPos;[in(1)+1,in(2)-1]];
        end
        if in(1)==2 && field{in(1)+2,in(2)}==' '
             posPos=[posPos;[in(1)+2,in(2)]];
        end
    else
        if field{in(1)-1,in(2)}==' '
            posPos=[posPos;[in(1)-1,in(2)]];
        end
        if  in(2)<8 && double(field{in(1)-1,in(2)+1})<95 &&...
                double(field{in(1)-1,in(2)+1})>40
            posPos=[posPos;[in(1)-1,in(2)+1]];
        end
        if  in(2)>1 && double(field{in(1)-1,in(2)-1})<95 &&...
                double(field{in(1)-1,in(2)-1})>40
            posPos=[posPos;[in(1)-1,in(2)-1]];
        end
        if in(1)==7 && field{in(1)-2,in(2)}==' '
             posPos=[posPos;[in(1)-2,in(2)]];
        end
    end
end